#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h> 
typedef struct Node_
{
    int data;
	char car;
    char* string;
	struct Node_ *next;
}node;
node* insert(int ifstring,char carh,char*stringz,int integer, node* head,int type){ // change current head with insert
    // type =0 = number; type 1 = alpha
    // carh can be number or letter
    node* newhead = (node*) malloc(sizeof(node));
    if(newhead==NULL){
        printf("Memory cannot be allocated");
        
    }
    //first nonifstring
    // 0 = no stringz 1=stringthem
    if(ifstring==0){
        newhead->car = carh;
        
    }else{
        if(ifstring==1){
            if(type != 0){
            newhead->string = stringz;
            }else{
                if(type==0){
                    newhead ->data  = integer;
                    
                }
            }
        }
    }
    newhead->next = head;
    return newhead;
}

 void print_array (char ** array, int size)
{
    int i;
    for (i = 0; i < size; i++) {
        printf ("%s\n", array[i]);
    }
}

int cmpstr(void* v1, void* v2) 
{ 
    char *a1 = (char*)v1; 
    char *a2 = (char*)v2; 
    int i = 0;
   
    while (a1[i]!='\0'  && a2[i]!='\0'  )
    {
        if (a1[i] > a2[i])
        {
           return 1;
        }
        else if (a1[i] < a2[i])
        {
            return -1;
        }
        i++;
    }
 if(a1[i]=='\0'){

return -1;

}else{

return 1;
}
    return 0;
}
int cmpnum(void* s1, void* s2) 
{ 
    int *a = (int*)s1; 
    int *b = (int*)s2;

    if ((*a) > (*b)) 
        return 1; 
    else if ((*a) < (*b)) 
        return -1; 
    else
        return 0; 
}


int cpint(int a,int b){
if(a>b)
return 1;
else if (a<b)
return -1;
else
return 0;
}
 void swap (char ** array, int a, int b)
{
     char * hold;
    hold = array[a];
    array[a] = array[b];
    array[b] = hold;
}
void quick_sort (char ** array, int left, int right)
{
    int pivot;
    int i;
    int j;
    char * key;
    if (right - left == 1) {


        if (strcmp (array[left], array[right]) > 0) {

            swap (array, left, right);
        }
        return;
    }
    pivot = (left + right) / 2;
    key = array[pivot];
    swap (array, left, pivot);
    i = left + 1;
    j = right;
 while (cpint(i,j)==-1) {
        while (i <= right && cmpstr (array[i], key) < 0) {
            i++;
        }
        while (j >= left && cmpstr (array[j], key) > 0) {
            j--;
        }
        if (i < j) {
            swap (array, i, j);
        }
    }
    swap (array, left, j);

    if (left < j - 1) {
	
        quick_sort (array, left, j - 1);
    }

    if (j + 1 < right) {
	
        quick_sort (array, j + 1, right);
    }
}
//integer quicksort
int * quicksort(int number[],int first,int last){
int i, j, pivot, temp;
if(cmpnum(&first,&last)==-1){
//Choosing pivot as first as asked in the directions
pivot=first;
i=first;
j=last;
while(i<j){
while(cmpnum(&number[i],&number[pivot])<=0 && cmpnum(&i,&last)==-1 )
i++;
while(cmpnum(&number[j],&number[pivot])==1)
j--;
if(cmpnum(&i,&j)==-1){
temp=number[i];
number[i]=number[j];
number[j]=temp;
}
}
temp=number[pivot];
number[pivot]=number[j];
number[j]=temp;
quicksort(number,first,j-1);
quicksort(number,j+1,last);
}

return number;
}


int quickSort( void* toSort, int (*comparator)(void*, void*)){


node* front = (node*) toSort;


int length=0;

node *ptr2=front;

while(ptr2!=NULL){
length++;
ptr2=ptr2->next;

}
if(comparator==&cmpnum){
int *arr=(int*)malloc(length*sizeof(int));
    if(arr==NULL){
        printf("Memory cannot be allocated");
       
    }
node* ptr = front;
int *qSortArr=(int *)malloc(sizeof(int)*length);
if(qSortArr==NULL){
        printf("Memory cannot be allocated");
        
    }
int i =0;
int size=0;

//putting elements in an array
while(ptr!=NULL){

arr[i]=ptr->data;
i++;
ptr=ptr->next;
size++;
}
 qSortArr=quicksort(arr,0,size-1);
int n=0;
for(n=0; n<size;n++){

printf("%d\n",qSortArr[n]);
}
free(arr);
}else{
//it is a string 
node* ptr = front;
int size=0;
char** arr=malloc(length*sizeof(char*));
if(arr==NULL){
        printf("Memory cannot be allocated");
        
    }
// char **qSortArr=(char **)malloc(sizeof(int)*length);
int i=0;

while(ptr!=NULL){
 
    arr[i]=ptr->string;
      i++;
      size++;

    ptr=ptr->next;
}



    quick_sort(arr,0,size-1);

      print_array (arr, size);
    free(arr);
}



}



int insertionSort( void* toSort, int (*comparator)(void*, void*)   ){
node* front = (node*) toSort;

int length=0;

node *ptr2=front;

while(ptr2!=NULL){
length++;
ptr2=ptr2->next;

}


if(comparator==&cmpnum){

//have to malloc array  
int *arr=malloc(length*sizeof(int));
if(arr==NULL){
        printf("Memory cannot be allocated");
        
    }
node* ptr = front;
int i =0;
int size=0;

//putting elements in an array
while(ptr!=NULL){

arr[i]=ptr->data;
i++;
ptr=ptr->next;
size++;
}
//Now sorting the array using int insertionsort
    int k, key, j; 
    for (k = 1; k < size; k++) { 
        key = arr[k]; 
        j = k - 1; 

        while (j >= 0 && (cmpnum(&arr[j],&key)==1 )) {

            arr[j + 1] = arr[j]; //use the comparator method to make comparison
            j = j - 1; 

        arr[j + 1] = key; 
    }
    }

    int d;
    for(d=0; d<size;d++){
    printf("%d\n",arr[d]);

} 
free(arr);
}else{
node* ptr = front;
int size=0;
 char** arr=malloc(length*sizeof(char*));
 if(arr==NULL){
        printf("Memory cannot be allocated");
        
    }
int i=0;

while(ptr!=NULL){

    arr[i]=ptr->string;
    i++;
    size++;

    ptr=ptr->next;
}

  int k;
  int j;
    char* key; 

    for (k = 1; k < size; k++) { 
        key = arr[k]; 
        j = k - 1;
        
        while (j >= 0 && (cmpstr(arr[j], key) == 1)) {

            arr[j + 1] = arr[j]; //use the comparator method to make comparison
            j = j - 1; 
    	}


        arr[j + 1] = key; 
    } 

//save it for later 

int t=0;
for(t=0; t<size;t++){

printf("%s\n",arr[t]);
}
free(arr);
}
    return 0 ;


}
void printList(node* n,int type)
{
    while (n != NULL) {
        if(type==0){ 
        printf(" %d->", n->data);
        n = n->next;
        }
        else{
            printf(" %s->", n->string);
        n = n->next;
        } 
    } 
}
void printArray(char* arrax){
    printf("\n");
    printf("%s",arrax);
}
void freemeth(node*head){
    while(head!=NULL){
        node* ptr = head;
        head = head->next;
        free(ptr);
    }
}
int main(int argc, char** argv){
    int fd;
    if(argc<3){
        printf("Fatal Error: expected two arguments, had one");
        exit(1);
    }
    if(argc>3){
        printf("Error: expected two arguements, had more than three");
        exit(1);
    }
    char flag = argv[1][1];
    if(strlen(argv[1])!=2||argv[1][0]!='-'){
        printf("Fatal Error: \"%s\" is not a valid sort flag",argv[1]);
    }
    int valid =0;
    if(flag=='i'||flag=='q'){
        valid+1;
    }else{
        printf("Fatal Error: \"%s\" is not a valid sort flag",argv[1]);
    }
    fd = open(argv[2],O_RDONLY);
    if(fd<0){
        printf("Fatal Error: file \"%s\" does not exist",argv[2]);
        exit(1);
    }
    int rd=69; // end of file integer if return 0, means eof
    char buffer[1];
    char *array = (char*) malloc(sizeof(char));
    if(array==NULL){
        printf("Memory cannot be allocated");
        
    }
    int first = -1;
    int sizeofarray=0;
    while(rd>0){
        rd =read(fd,buffer,1);
        if(buffer[0]==' '||buffer[0]=='\n'||buffer[0]=='\t'){
                continue;
            }
        if(rd <= 0){
            if (rd < 0) perror("read");
                break;
        }
        
        if(first==-1)
        {
            array[sizeofarray] = buffer[0];
            if(buffer[0]==','){
                continue;    
            }
            first = 0;
            sizeofarray++;
                
        }else{
            array = realloc(array,(sizeofarray+1)*sizeof(char));
            if(array!=NULL){
            array[sizeofarray] = buffer[0];           
            sizeofarray++;
            }
            else{
                printf("Not enough Memory allocated");
                
            }
        }
    }
    array = realloc(array,(sizeofarray+1)*sizeof(char));
    if(array==NULL){
        printf("Memory cannot be allocated");
        
    }
    sizeofarray++;
    array[sizeofarray-1] = '\0';
    int Truue=0;
    int new;
    int numnum=0;
    int numalpha=0;
    for(new=0;new<strlen(array);new++)
    {
        if(array[0]==',')
        {
            continue;
        }
        else{
            Truue =1;
        }
        if(isalpha(array[new])==0&&array[new]!=','){
            //number
            numnum++;
        }
        if(isdigit(array[new])==0&&array[new]!=','){
            //alpha
            numalpha++;
        }
    }
    int type;
    if(numalpha==0&&numnum>0)
    {
        type==0;
    }else{
        if(numalpha>0&&numnum==0){
            type=1;
        }
        else{
        printf("ERROR: The file contains both letters and numbers");
        exit(1);
    }
    }
    if(Truue==0){
        printf("Warning!: This file may be empty/have empty tokens");
    }
    close(fd);
    int arraycounter;
    node* head =NULL; // char linked list
    int sizeword = 0;
    node* finalhead =NULL; // string linked list
    char* newarray;
    for(arraycounter=0; arraycounter<sizeofarray; arraycounter++){
        char charater = array[arraycounter];
        if(charater=='\0'||charater==',')
        {
            if(array[arraycounter+1]==','&&charater!='\0'){
                continue;
            }
            if(sizeword==0&&charater=='\0'){
                continue;
                
            }
            newarray = (char*) malloc(sizeof(char)*sizeword+1);
            if(newarray==NULL){
                printf("Memory cannot be allocated");
                
            }
            int arraypointer;
            newarray[sizeword]='\0';   
            node* pointer  = head;
            for(arraypointer=sizeword-1; arraypointer>=0; arraypointer--){
                newarray[arraypointer] = pointer->car;
                pointer = pointer->next;
            }
            sizeword= 0;
            if(type==0){
                int number  = atoi(newarray);
                finalhead = insert(1,'5',NULL,number,finalhead,type);
                
            }
            else{
                if(type !=0){
                    
                    finalhead = insert(1,'\0',newarray,-5,finalhead,type);
                    

                    
                    
                }
            }
                
                continue;
        }
        head = insert(0,charater, NULL,-100,head,type);
        
        sizeword++;
    }
    int(*comparator)(void*,void*);
    if(type==0){
    comparator=&cmpnum;
    }
    if(type==1){
        comparator==&cmpstr;
    }
    if(flag=='i'){
        insertionSort(finalhead,comparator);
    }
    if(flag=='q'){
        quickSort(finalhead,comparator);
    }
    free(array);
    freemeth(head);
    freemeth(finalhead);
    free(newarray);

    return 0;
}

