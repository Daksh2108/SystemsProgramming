#include<stdlib.h>
#include<dirent.h>
#include<string.h>
#include<stdio.h>
#include<sys/stat.h>
#include<unistd.h>
#include<fcntl.h>
#include<limits.h>
#include<sys/types.h>
#define maximum INT_MAX 



typedef struct NodeItems {
	 int freq;
	char * strings;
	struct NodeItems * next;
} NodeItems;

NodeItems * front = NULL;
typedef struct _Node {
	char * strings;

	 int freq;
	
	struct _Node *left;

        struct _Node *right;
} _Node;

typedef struct treeNode {
	 int size;
	
	 int mSize;
	_Node ** Array;
} treeNode;


int count(char * arr, int length);
void compress(int fdir, char * arr, int length, char ** cod, char ** str, int size);
void decompress(int fdir, char * arr, int length, char ** cod, char ** str, int size);
void huffman(int size, NodeItems * node, int fdir);
_Node * makeNode(char * string,  int freq);
treeNode * buildTree( int mSize);
void swap(_Node ** first, _Node ** second);
void heapify(treeNode * ROOT, int length);
_Node * getLast(treeNode * ROOT);
void insert(treeNode * ROOT, _Node * node);
void makeTree(treeNode * ROOT);
treeNode * completeTree( int size, NodeItems * node);
_Node * buildHuffman( int size, NodeItems * node);
void setCod(_Node * node,  short code_arr[], int parent, int fdir);
void huffman(int size, NodeItems * ROOT, int fdir);
int codebookTotal(char * arr, int length);
int findStr(char ** arr, int size, char * string);
void compress(int fdir, char * arr, int length, char ** cod, char ** str, int size);
void decompress(int fdir, char * arr, int length, char ** cod, char ** str, int size);
int strList(char * strings);
 int strSize(char * arr);
void codebooktraverse(char ** cod, char ** str, char * arr, int length);
int dirRec(int fdir, char * di_name, char flag, char ** cod, char ** str, int size);

//Revisted 
//***************************************************************************************************************************************************************************************************
char** convert(char* arr,int size,int unique){
    // \t\n
    int i;
    int length=0;
    char** converted = (char**) malloc(unique*(sizeof(char*)));
    int convertlength=0;
    char* newarray = (char*) malloc(1+(size*(sizeof(char))));
        for(i=0;i<size;i++){
            newarray[i]=arr[i];
        }
        newarray[size]= '\0';
        i=0;
        int extralength=0;
    while(arr[i]==' '||arr[i]=='\n'||arr[i]=='\t'){
        char* z = malloc(sizeof(char)+1);
        z[0]=arr[i];
        z[1]='\0';
        converted[convertlength]=z;
        convertlength++;
        extralength++;
        i++;
    }
       
    char* token =strtok(arr,"\t\n ");
    while( token != NULL ) {
    char* string = (char*) malloc(1+(strlen(token)*(sizeof(char))));
    strcpy(string,token);
    converted[convertlength] = string;
    convertlength++;
  
    char car =  newarray[strlen(string)+length+extralength];
    length+=strlen(string)+1;
    char* another = (char*) malloc(sizeof(char)+1);
    another[0]=car;
    another[1]='\0';
    converted[convertlength] = another;
    convertlength++;
      token = strtok(NULL, "\t\n ");
   }
   return converted;
}



//*********************************************************************************************************************************************
int main(int argc, char ** argv) {

	int isRecursive = 0;
	

   //bad arr check for arguments 
	if (argc < 3  || argc > 5 ) { 
		printf("Bad Arg arr\n");
		return 0;
	}
	int boolDir = 1;
	char flag = ' ';

//FAQ says -R is always argv1 but ass1 pdf says -r could be argv1 or argv2, handled just incase 
	 int cmp1=strcmp("-R",argv[1]);
	int cmp2= strcmp("-R",argv[2]);
	
	if (cmp1 == 0 ||cmp2  == 0) {
		isRecursive = 1;
	}

	char * di_name = argv[3 + (isRecursive - 1)];
	if (isRecursive) {
		 //means that the flag needs to be pulled out from next argument
		if (strcmp("-R", argv[1]) == 0) {
			flag = argv[2][1];
		} else {
			flag = argv[1][1];
		}
	} else {
		flag = argv[1][1];
	}
	if (flag != 'd' && flag != 'b' && flag != 'c') {
		printf("Error : Wrong flag input \n");
		return 0;
	}
	if (isRecursive) {
		struct stat fstat;
		if (stat(di_name, &fstat) != 0) {
			printf("Such testcase file does not exit \n");
			return 0;
		}
		boolDir = S_ISREG(fstat.st_mode); 
		if (boolDir) {
			//checking path
			int cPath = 0;
			int j=0;

			while(j < strlen(di_name)){
	          if (di_name[j] == '/') {
					cPath = 1;
					break;
				}
		      j++;

			}
		
		}

		 int diLen=(strlen(di_name));

		if (di_name[diLen - 1] == '/') {
			di_name[diLen - 1] = '\0';
		}
	}
	if (boolDir) {

		int dirFile = open(di_name, O_RDONLY);

		if (dirFile < 0) {
			printf("File can't open \n");
			return 0;
		}

		char * holdArr = (char *)malloc(sizeof(char) * maximum);

		if(holdArr==NULL){
			 printf("Memory not enough to malloc \n");

          return 0;
		}
		int length = read(dirFile, holdArr, maximum);
		char * arr = (char *)malloc(sizeof(char) * (length + 1));

      //malloc can return null
		if(arr==NULL){

        printf("Memory not enough to malloc \n");

		}
		//copy because needs
		strcpy(arr, holdArr);
		free(holdArr);
		if (flag == 'b') {
			if ((argc > (4 + isRecursive - 1)) || (argc < (4 + isRecursive - 1) )) {
				printf("Bad argument input.\n");
				return 0;
			}
			//making codebook
			int codebook = open("./HuffmanCodebook", O_WRONLY | O_CREAT | O_TRUNC, 0644);

            //checking created or not
			if (codebook < 0) {
				printf("codebook cannot be created\n");
				return 0;
			}

			int size = strSize(arr);//total number of unique str
			if (size > 0) {
				huffman(size, front, codebook);
			} 

			write(codebook,"\n",1);
			close(codebook);
		}
		if (flag == 'c' || flag == 'd') {
			if ((argc > (5 + isRecursive - 1)) || (argc < (5 + isRecursive - 1) )) {
				printf("Bad argument input\n");
				return 0;
			} 
			//opening codebook
			int codebook = open(argv[argc - 1], O_RDONLY);
			if (codebook < 0) {
				printf("Can't open codebook\n");
				return 0;
			}

			holdArr = (char *)malloc(sizeof(char) * maximum);

			 if(holdArr==NULL){
             printf("Memory not enough to malloc \n");
               return 0;
			 }

			int lenCode = read(codebook, holdArr, maximum);
			char * codeBookItem = (char *)malloc(sizeof(char) * (lenCode + 1));
             if(codeBookItem==NULL){
             printf("Memory not enough to malloc \n");
               return 0;
			 }


			strcpy(codeBookItem, holdArr);
			free(holdArr);

			int size = codebookTotal(codeBookItem, lenCode);
			 if(size<0){

				 printf("No items are in codebook \n");
			 }
			char ** cod = (char **)malloc(sizeof(char *) * size);

			 if(cod==NULL){
             printf("Memory not enough to malloc \n");
               return 0;
			 }


			char ** str = (char **)malloc(sizeof(char *) * size);


			 if(str==NULL){
             printf("Memory not enough to malloc \n");
               return 0;
			 }


			codebooktraverse(cod, str, codeBookItem, lenCode);// adds all the str from codebook
			if (flag == 'c') {
				char * hczFile = strcat(di_name, ".hcz");// creates the .hcz di_name
				int hzc = open(hczFile, O_WRONLY | O_CREAT | O_APPEND, 0644);
				if (hzc < 1) {
					printf("Error opening hczFile");
					return 0;
				}
                //printf("%s ",arr);
                // convert this shit into an string array
                ///////////////////////////////////////////////////////
                // char** strinarr = convert(arr,length);
                // printf("size: %d\n",length);
                // printf("%s",cod[0]);
                // printf("%s\n",str[0]);
                // printf("size: %d\n",size);p s
				compress(hzc, arr, length, cod, str, size);
				//closing the hczFiles
				close(hzc);
			} else {
				char * test = (char *)malloc(sizeof(char) * 5);

				 if(test==NULL){
                  printf("Memory not enough to malloc \n");
                  return 0;
			  }
                   int cropName= strlen(di_name) - 4;
				    test = di_name + cropName;

					int compareF=(strcmp(test, ".hcz"));


                //checking whether user entered correct hcz type file or not
				if (compareF != 0) {
					printf("Did not enter a valid hcz fileName");
					return 0;
				}
				
				char * dirName = di_name;
				int crop_Name=strlen(di_name) - 4;
				dirName[crop_Name] = '\0';	

				int directory = open("fakeass.txt", O_WRONLY | O_CREAT , 0644);
				
				if (directory < 1) {
					printf("Directory not found  \n");
					return 0;
				}
				decompress(directory, arr, length, cod, str, size);
			
			}
			 
		}
		        
	} else {// if isRecursive means the flags are atlest 4 
		if (flag == 'b') {
			if (argc < 4  || argc > 4 ) {
				printf("Bad arg Input\n");
				return 0;
			}
			int codebook = open("./HuffmanCodebook", O_WRONLY | O_CREAT | O_TRUNC, 0644);	
			if (codebook < 0) {
				printf("CANNOT OPEN HUFFMAN CODEBOOK\n");
				return 0;
			}
			int size = dirRec(codebook, di_name, flag, NULL, NULL, 0);//creates one codebook for all the di_names
			if (size > 0) {
				huffman(size, front, codebook);	
			} 
			write(codebook,"\n",1);
			close(codebook);
		} else if (flag == 'c' || flag == 'd') {
			if (argc < 5) {
				printf("Invalid number of flags/arguments. Not enough.\n");
				return 0;
			} else if (argc > 5) {
				printf("Invalid number of flags/arguments. Too many.\n");
				return 0;
			}
			int codebook = open(argv[argc - 1], O_RDONLY);
			if (codebook < 0) {
				printf("Can't open the di_name \"%s\".\n", argv[argc - 1]);
				return 0;
			}
			char * holdArr = (char *)malloc(sizeof(char) * maximum); // gets the entire codebook in a string
			int lenCode = read(codebook, holdArr, maximum);
			char * codeBookItem = (char *)malloc(sizeof(char) * (lenCode + 1));
			strcpy(codeBookItem, holdArr);
			free(holdArr);
			int size = codebookTotal(codeBookItem, lenCode);
			char ** cod = (char **)malloc(sizeof(char *) * size);
			char ** str = (char **)malloc(sizeof(char *) * size);
			codebooktraverse(cod, str, codeBookItem, lenCode);
			dirRec(0, di_name, flag, cod, str, size);
			free(cod);
			free(str);
			close(codebook);
		}
	}
	free(front);
	return 0;
}

//Revisted (once)
//***************************************************************************************************************************************************************************************************

_Node * makeNode(char * string,  int freq) {
	
	_Node * current = (_Node *)malloc(sizeof(_Node));

	current->right = NULL;

	current->left = NULL;


	current->strings = (char *)malloc(strlen(string) + 1);

	strncpy(current->strings, string, (strlen(string)));	

	current->freq = freq;

	return current;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
treeNode * buildTree( int mSize) { // starts the tree
	treeNode * current = (treeNode *)malloc(sizeof(treeNode)); 
	current->size = 0;
	current->mSize = mSize;
	current->Array = (_Node **)malloc(mSize * sizeof(_Node *));
	return current;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
void swap(_Node ** first, _Node ** second) {
	_Node * holdArr = *first;
	*first = *second;
	*second = holdArr;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
void heapify(treeNode * ROOT, int length) { 
	int parent = length;//parents
	int leftChild = 2 * length + 1;
         int rightChild = 2 * length + 2;
	
	if (leftChild < ROOT->size && ROOT->Array[leftChild] != NULL && ROOT->Array[parent] != NULL && ROOT->Array[leftChild]->freq < ROOT->Array[parent]->freq) {
		parent = leftChild;
	}
	if (rightChild < ROOT->size && ROOT->Array[rightChild] != NULL && ROOT->Array[parent] != NULL && ROOT->Array[rightChild]->freq < ROOT->Array[parent]->freq) {
		parent = rightChild;
	}
	if (ROOT->Array[parent] != NULL && ROOT->Array[length] != NULL && parent != length) {
		swap(&ROOT->Array[parent], &ROOT->Array[length]);
		heapify(ROOT, parent);
	}
	return;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
_Node * getLast(treeNode * ROOT) { 
	_Node * current = ROOT->Array[0];
	int i = 1;
	ROOT->Array[0] = ROOT->Array[ROOT->size - i];
	--ROOT->size;
	heapify(ROOT, 0);
	return current;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
void insert(treeNode * ROOT, _Node * node) { 
	++ROOT->size;
	int i = ROOT->size - 1;
	while (i > 0 && ROOT->Array[(i - 1)/2] != NULL && node->freq < ROOT->Array[(i - 1)/2]->freq) {
		ROOT->Array[i] = ROOT->Array[(i - 1) / 2];
		i = (i - 1) / 2;
	}
	ROOT->Array[i] = node;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
void makeTree(treeNode * ROOT) { 
	int i = 0;
	int j = ROOT->size - 1;
	for (i = (j - 1) / 2; i >= 0; --i) {
		heapify(ROOT, i);
	}

}
//Revisted 
//***************************************************************************************************************************************************************************************************

treeNode * completeTree( int size, NodeItems * node) { 
	treeNode * ROOT = buildTree(size);
	NodeItems * current = node;
	int i = 0;
	for (i = 0; i < size; i++) {
		ROOT->Array[i] = makeNode(current->strings, current->freq);
		current = current->next;
		if (current == NULL) {
			break;
		}
	}
	ROOT->size = size;
	makeTree(ROOT);
	return ROOT;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
_Node * buildHuffman( int size, NodeItems * node) {
	_Node * parent;
	_Node * left;
	_Node * right;
	treeNode * ROOT = completeTree(size, node);

               
	while (ROOT->size != 1) {
		left = getLast(ROOT);
		right = getLast(ROOT);
		int leftfreq = 0;
                int rightfreq = 0;
		if (left != NULL) {
			leftfreq = left->freq;
		}
		if (right != NULL) {
			rightfreq = right->freq;
		}
		char holdArr[3] = "/\\\0";
		parent = makeNode(holdArr, leftfreq + rightfreq);
		parent->left = left;
		parent->right = right;
		insert(ROOT, parent);
	}
	return getLast(ROOT);
}

//Revisted 
//************************************************************************************************************************************************************************************************
void setCod(_Node * node,  short code_arr[], int parent, int fdir) { 
	if (node->left != NULL) {
		code_arr[parent] = 0;
		setCod(node->left, code_arr, parent+1, fdir);
	}
	if (node->right != NULL) {
		code_arr[parent] = 1;
		setCod(node->right, code_arr, parent+1, fdir);
	}
	if (node->left == NULL && node->right == NULL) {
		int i = 0;
		char buf[parent];
		int count = 0;
		for (i = 0; i < parent; i++) { 
			if (code_arr[i] == 1 || code_arr[i] == 0) {
				buf[i] = code_arr[i] + '0';
				count=count+1;
			} else {
				break;
			}
		}
		write(fdir, buf, count);
		write(fdir, "\t", 1);
		write(fdir, node->strings, strlen(node->strings));
		write(fdir, "\n", 1);
	}
}
//Revisted 
//***************************************************************************************************************************************************************************************************
void huffman(int size, NodeItems * ROOT, int fdir) {
	_Node * base = buildHuffman(size, ROOT);
	short cod[size];
	setCod(base, cod, 0, fdir);
}

//Revisted 
//***************************************************************************************************************************************************************************************************




//Revisted 

//***************************************************************************************************************************************************************************************************
int codebookTotal(char * arr, int length) {
	int count = 0;
	int i = 0;
	for (i = 0; i < length; i++) {
		if (arr[i] == '\t') {
			count=count+1;
		}
	}
	return count;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
int findStr(char ** arr, int size, char * string) { 
	int i = 0;
	for (i = 0; i < size; ++i) {
		if (strcmp(arr[i], string) == 0) {
			return i;
		}
	}
	return -1;
}
//Revisted 
//***************************************************************************************************************************************************************************************************
int isnull= 0;
int* points = &isnull;
char* lookup(char*stringarray,int size,char** cod,char**str,int*points){
    int i;
	

    for(i=0;i<size;i++){
		if(strcmp(stringarray," \0")==0){
			if(strcmp("~)!(@s*#&$^\0",str[i])==0){
				return cod[i];
			}
		}
		if(strcmp(stringarray,"\t\0")==0){
			if(strcmp("~)!(@t*#&$^\0",str[i])==0){
				return cod[i];
			}
		}
		if(strcmp(stringarray,"\n\0")==0){
			if(strcmp("~)!(@n*#&$^\0",str[i])==0){
				return cod[i];
			}
		}
		if(strcmp(stringarray,"\n\0")!=0&&strcmp(stringarray,"\t\0")!=0&&strcmp(stringarray," \0")!=0){
			if(strcmp(stringarray,str[i])==0){
				return cod[i];
			}
		}
    }
	*points = 1;
	return cod[0];
}
void compress(int fdir, char * arr, int length, char ** cod, char ** str, int size) { 
	//fdir = file to write into
    //arr original array of inputs
    //length = size of the original inputs
    //cod ==  array of code to a string
    // str == array of strings
    //size == num of unqiues
	char** stringarray= convert(arr,length,size);//
    int i;
	//printf("length:%d",size);
    for(i=0;i<size+1;i++){
		
     char* x = lookup(stringarray[i],size,cod,str,points);
	 printf("%s",x);
	 	if((*points)!=1){
        	write(fdir,x,(strlen(x)));
		}
    }
}
//Revisted 
//***************************************************************************************************************************************************************************************************
void decompress(int fdir, char * arr, int length, char ** cod, char ** str, int size) { 
	int i = 0, j = 0;
	int brkL = 0;
	int len = 0;
	for (i = 0; i < length; i++) {
		len++;
		char * code = (char *)malloc(sizeof(char) * (len + 1));
		for (j = 0; j < len;j++) {
			code[j] = arr[brkL + j];
		}
		code[len] = '\0';
		int length = findStr(cod, size, code);// chearches the codebook for the codes
		if (length >= 0) {
			if (strcmp(str[length], "~)!(@s*#&$^") == 0) { // Spaces and tabs are dealt with here
				write(fdir, " ", strlen(" "));
			} else if (strcmp(str[length], "~)!(@t*#&$^") == 0) {
				write(fdir, "\t", strlen("\t"));
			} else if (strcmp(str[length], "~)!(@n*#&$^") == 0) {
				write(fdir, "\n", strlen("\n"));
			} else {
				write(fdir, str[length], strlen(str[length]));
			}
			brkL += len;
			len = 0;
		}
		free(code);
	}
}
//Revisted 
//***************************************************************************************************************************************************************************************************
int strList(char * strings) { 
	NodeItems * holdArr;
	NodeItems * current;
	holdArr = (NodeItems *)malloc(sizeof(NodeItems));
	if (holdArr == NULL) {
		printf("Not enough memory left.\n");
		return -1;
	}
	holdArr->freq = 1;
	holdArr->strings = (char *)malloc(strlen(strings) + 1);
	strncpy(holdArr->strings, strings, (strlen(strings)));

	if (front == NULL) {
		front = holdArr;
		holdArr->next = NULL;
		return 1;
	}

	if (strcmp(strings, (front->strings)) == 0) {

		++front->freq;
		return 0;
	}
	if (holdArr->freq <= front->freq && front->next == NULL) {

		holdArr->next = front;
		front = holdArr;
		return 1;
	}

	current = front;
	while (current->next != NULL) {
		if(strcmp(current->next->strings, strings) == 0) {
			++current->next->freq;
			return 0;
		}
		current = current->next;
	}

	current->next = holdArr;
	holdArr->next = NULL;
	return 1;
}
//Revisted 
//***************************************************************************************************************************************************************************************************

 int strSize(char * arr) { 
	if (arr == NULL || strlen(arr) == 0) { 
		return 0;
	}
	int count2 = 1;
	int rep = 0;
	int i = 0, j = 0;
	int totalLen = 0;
	int count = 0;
	int length = strlen(arr);
	int count3 = 1;

	for (i = 0; i < length; i++) {

		if (arr[i] != '\t' && arr[i] != '\n' && arr[i] != ' ') { 
			totalLen++;
			count2 = 0;
			count3 = 0;

		} else if (count2 == 0) {
			char * strings = (char *)malloc(sizeof(char) * (totalLen + 1));
			if (strings == NULL) {
				printf("Not enough memory left.\n");
				return -1;
			}
			int freq = 0;
			for (j = 0; j < totalLen; j++) {
				strings[j] = arr[rep + j];
			}
			strings[totalLen] = '\0';

			rep += totalLen + 1;
			int inc = strList(strings);
			if (inc == -1) {
				return -1;
			}
			count += inc;
			count2 = 1;
			totalLen = 0;
			count3 = 1;

		} else {
			rep++;
			count3 = 1;
		}

		if (count3 == 1) {
			int inc = 0;
            
			if(arr[i] == ' ') {
				inc = strList("~)!(@s*#&$^");
				if (inc == -1) {
					return -1;
				}
			} else if (arr[i] == '\t') {
				inc = strList("~)!(@t*#&$^");
				if (inc == -1) {
					return -1;
				}
			} else {
				inc = strList("~)!(@n*#&$^");
				if (inc == -1) {
					return -1;
				}
			}
			count += inc;
		}
	}

	
	if (totalLen > 0) {
		char * strings = (char *)malloc(sizeof(char) * (totalLen + 1));
		if (strings == NULL) {
			printf("Not enough memory.\n");
			return -1;
		}
		for (j = 0; j < totalLen; j++) {
			strings[j] = arr[rep + j];
		}
		strings[totalLen] = '\0';
		int inc = strList(strings);
		if (inc == -1) {
			return -1;
		}
		count += inc;
	}
	return count;
}

//***************************************************************************************************************************************************************************************************
void codebooktraverse(char ** cod, char ** str, char * arr, int length) {
	int i = 0, j = 0;
	int whtspcL = 0;
	int stnLength = 0;
	int index = 0;
	for (i = 0; i < length - 1; i++) {
		if (arr[i] == '\t' || arr[i] == '\n') {
			char * string = (char *)malloc(sizeof(char) * (stnLength + 1));
			for (j = 0; j < stnLength; j++) {
				string[j] = arr[whtspcL + j];
			}
			string[stnLength] = '\0';
			whtspcL += stnLength + 1;
			stnLength = 0;
			if (arr[i] == '\t') { 
				cod[index] = (char *)malloc(strlen(string) + 1);



				strncpy(cod[index], string, (strlen(string)));


			} else {
				str[index] = (char *)malloc(strlen(string) + 1);
				strncpy(str[index], string, (strlen(string)));
				index=index+1;
			}
			free(string);
		} else {
			stnLength++;
		}
	}
}

//***************************************************************************************************************************************************************************************************
int dirRec(int fdir, char * di_name, char flag, char ** cod, char ** str, int size) { 
	DIR * direc;
	//Directory pointer
	struct dirent * dp;
	int total = 0; 
    direc = opendir(di_name);

	if(direc < 0){
   
    printf("Error directory does not exist");
     return 1;
	}
	while ((dp = readdir(direc)) != NULL) { 

		char prefix[20000];

		
		snprintf(prefix, sizeof(prefix), "%s/%s", di_name, dp->d_name);

		
		if (dp->d_type == DT_DIR) {	
			 // Skips hidden file
			 int compare1=strcmp(dp->d_name, "..");
			 int compare2=strcmp(dp->d_name, ".") ;
			if ( compare1== 0 || compare2== 0 ) {
				continue;
			}
			total = total + dirRec(fdir, prefix, flag, cod, str, size);


			//else has files within the directory 
		} else { 

			
			int dirFile = open(prefix, O_RDONLY);
			char * holdArr = (char *)malloc(sizeof(char) * maximum);
            
			int length = read(dirFile, holdArr, maximum);
        	char * arr = (char *)malloc(sizeof(char) * (length + 1));
			strcpy(arr, holdArr); 
			free(holdArr);
			if (flag == 'b') {
				total = total + strSize(arr);
			} else if (flag == 'd') {

				char * test = (char *)malloc(sizeof(char) * 5);
				 if(test==NULL){

                 printf("cannot malloc \n");

				 }
                

				int cropName=strlen(prefix) - 4;
				test = prefix + cropName;
				int compare3=strcmp(test, ".hcz");

				if ( compare3 !=0) {
					continue;
				}

			
				char * dirName = prefix;
				int reindex=(strlen(prefix) - 4);

				dirName[reindex] = '\0';

				int directory = open(dirName, O_WRONLY | O_CREAT , 0644);
				if (directory < 0) {
					printf("Not able to create/open %s. Therefore skipped %s.\n", dirName, prefix);
					continue;
				}
				decompress(directory, arr, length, cod, str, size);
				close(directory);
			} else if (flag == 'c') {
				char * hczFile = strcat(prefix, ".hcz");
				int hzc = open(hczFile, O_WRONLY | O_CREAT , 0644);
				if (hzc < 0) {
					printf("Unable to create hcz file\n");
					continue;
				}
				
				compress(hzc, arr, length, cod, str, size);
				//close file 
				close(hzc);
			}
		}
	}
	
	closedir(direc);
	return total;
}

